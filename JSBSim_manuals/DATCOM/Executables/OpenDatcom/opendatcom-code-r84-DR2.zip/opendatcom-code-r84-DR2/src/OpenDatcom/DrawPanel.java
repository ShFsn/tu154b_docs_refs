package OpenDatcom;

import javax.swing.JPanel;

/**
 * Class implements a basic JPanel that has functions for 2D drawing and plotting.
 * @author -B-
 */
public class DrawPanel extends JPanel {
    public void DrawPanel()
    {
    }
}
