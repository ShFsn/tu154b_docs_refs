/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Core;

/**
 *
 * @author -B-
 */
public interface  OAE_Component {
    public abstract void refresh();
    public abstract String getName();
    public abstract void writeBack();
}
